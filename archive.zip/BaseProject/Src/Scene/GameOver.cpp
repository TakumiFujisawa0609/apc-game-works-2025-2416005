#include "GameOver.h"

GameOver::GameOver(void)
{
}

GameOver::~GameOver(void)
{
}

void GameOver::Init(void)
{
}

void GameOver::Update(void)
{
}

void GameOver::Draw(void)
{
}

void GameOver::Release(void)
{
}
