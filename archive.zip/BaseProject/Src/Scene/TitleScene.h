#pragma once
#include "SceneBase.h"
class Grid;
class Player;
class SlimeManager;

class TitleScene : public SceneBase
{

public:

	// �R���X�g���N�^
	TitleScene(void);

	// �f�X�g���N�^
	~TitleScene(void) override;

	void Init(void) override;
	void Update(void) override;
	void Draw(void) override;
	void Release(void) override;

private:

	// �O���b�h��
	Grid* grid_;

	Player* player_;

	SlimeManager* slime_;

	int imageId_;
};
