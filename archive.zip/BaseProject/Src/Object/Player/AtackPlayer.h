#pragma once

class AtackPlayer
{
public:
	AtackPlayer();
	~AtackPlayer();

	void Init(void);
	void Update(void);
	void Draw(void);
	void Release(void);

private:

};
