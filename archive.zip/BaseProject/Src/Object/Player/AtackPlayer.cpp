#include "AtackPlayer.h"

AtackPlayer::AtackPlayer()
{
}

AtackPlayer::~AtackPlayer()
{
}

void AtackPlayer::Init(void)
{
}

void AtackPlayer::Update(void)
{
}

void AtackPlayer::Draw(void)
{
}

void AtackPlayer::Release(void)
{
}
