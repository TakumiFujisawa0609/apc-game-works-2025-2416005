#include "AtackPlayerManager.h"


AtackPlayerManager* AtackPlayerManager::instance_ = nullptr;


AtackPlayerManager::AtackPlayerManager()
{
}

AtackPlayerManager::~AtackPlayerManager()
{
}

void AtackPlayerManager::AddAtack(const VECTOR& pos, const VECTOR& dir)
{
}

void AtackPlayerManager::Update(void)
{
}

void AtackPlayerManager::Draw(void)
{
}

void AtackPlayerManager::Release(void)
{
}
